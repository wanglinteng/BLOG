<?php

namespace Test\Controller;

use Think\Controller;

/**
 * 微信权限类控制器
 * @author MR.WLT
 */
class BaseController extends Controller
{	
	//进入授权引导
    public function index(){
    	$openid = cookie('openid');
    	if($openid){
			$this->redirect('');
    	}else{
	    	$appid = '';//微信平台的appid
		    $redirect_uri = urlencode('');//回调链接
			$url = 'https://open.weixin.qq.com/connect/oauth2/authorize?appid='.$appid.'&redirect_uri='.$redirect_uri.'&response_type=code&scope=snsapi_userinfo#wechat_redirect';//授权链接
			header("location:$url");//跳转链接
    	}
	}
	//获取access_token
	public function get($code = null){
		$appid = '';//微信平台的appid
		$appsecret = '';//微信平台的应用秘钥
		$url = 'https://api.weixin.qq.com/sns/oauth2/access_token?appid='.$appid.'&secret='.$appsecret.'&code='.$code.'&grant_type=authorization_code';//获取access_token 链接
		$data_json = file_get_contents($url);//请求返回数据
		$data = json_decode($data_json,true);//json=>数组//true时为数组否则为数组
		$access_token = $data['access_token'];//access_token 值
		$openid = $data['openid'];//openid 值
		$this->info($access_token,$openid);//提交给info方法获取用户信息
	}
	//拉取用户信息
	public function info($access_token = null,$openid = null){
		$url = 'https://api.weixin.qq.com/sns/userinfo?access_token='.$access_token.'&openid='.$openid.'&lang=zh_CN';//获取用户信息的url
		$data_json = file_get_contents($url);//请求返回数据
		$data = json_decode($data_json,true);//json=>数组
		cookie('openid',$data['openid']);
		$this->redirect('');
	}

}